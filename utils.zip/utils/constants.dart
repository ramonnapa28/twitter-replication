import 'package:flutter/material.dart';

const Color NU_YELLOW = Color(0xFFffd41d);
const Color NU_BLUE = Color(0xFF35408f);
